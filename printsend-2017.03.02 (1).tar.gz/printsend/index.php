<?php


	header("Location: send-email-form.php");

?>