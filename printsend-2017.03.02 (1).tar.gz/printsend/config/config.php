<?php

	$submissionaddress = 'printroom@exeterguild.com';

?>
